import sys
import os
import re
from time import sleep
import requests

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *

def import_market_data():
    retries = 0
    while retries <= max_retries:
        try:

            response = http("balsarest/marketdata/importMarketDataViaProvider", headers={"provider": params().provider}, method="POST")
            if 201 == response.status_code:
                return True
            else:
                log('Market data import failed, retrying...')
        except requests.RequestException as e:
            log(f'An error occurred: {e}')
            return False
        sleep(retry_interval_minutes * 60)
        retries += 1
    log('Max retries reached.')
    return False

if __name__ == '__main__':
    start_job()

    max_retries = int(params().max_retries)
    retry_interval_minutes = int(params().retry_interval_minutes)

    success = import_market_data()

    end_job(success)