import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *

def copy_forward_market_data():
    response = http("balsarest/marketdata/copyForwardMarketDataToNextPeriod", headers={"Company": params().company, "Commodity": params().commodity}, method="POST")
    log(response.text)

    if  response.status_code == 400 or response.status_code == 403:
        raise Exception("Copy Forward Market Data to Next Period Failed")
    return

start_job()
copy_forward_market_data()
end_job(True)
