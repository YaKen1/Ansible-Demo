import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

def DBChangeModeToSimple():
    result = sql("ALTER DATABASE BALSAMO SET RECOVERY SIMPLE")
    if (result == False):
        return False
    else:
        return True

def DBChangeModeToFull():
    result = sql("ALTER DATABASE BALSAMO SET RECOVERY FULL")
    if (result == False):
        return False
    else:
        return True


if __name__=='__main__':
    start_job()
    result = False
    if params().mode == 'Full':
        result = DBChangeModeToFull()
    else:
        result = DBChangeModeToSimple()
    end_job(result)