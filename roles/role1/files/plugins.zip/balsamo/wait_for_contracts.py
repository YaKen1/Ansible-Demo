import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *
from datetime import timedelta


def check_contracts():
    try:
        if "Contracts are all Loaded" in http("balsarest/system/areAllContractsLoadedInMemory").text:
            return True
        return False
    except:
        return False

start_job()
success = waitWithTimeout(check_contracts, timedelta(minutes=int(params().timeout)))
end_job(success)