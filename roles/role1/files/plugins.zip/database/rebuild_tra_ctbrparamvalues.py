import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

def rebuild_tra_ctbrparamvalues():
    log(str(datetime.now()) + " [INFO] Rebuilding TRA_CTBRPARAMVALUES ")
    result = sql("ALTER INDEX ALL ON [TRA_CTBRPARAMVALUES] REBUILD")
    if result is None:
        return True
    else:
        return False
    
if __name__ == '__main__':
    start_job()
    result = rebuild_tra_ctbrparamvalues()
    end_job(result)