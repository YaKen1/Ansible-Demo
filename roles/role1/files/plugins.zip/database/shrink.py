import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

start_job()
if params().what == "ALL" or params().what == "DB":
    sql("DBCC SHRINKDATABASE (" + conf().dbName + ")")
if params().what == "ALL" or params().what == "LOGS":
    sql("DBCC SHRINKFILE (" + conf().dbName + "_log , 1, TRUNCATEONLY)")
end_job(True)
