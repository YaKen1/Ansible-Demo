import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *


def import_market_data():
    coco = conf().cocos[0]
    text = http("balsarest/marketdata/importMarketDataViaProvider", headers={"company": coco.company,
                                                                             "commodity": coco.commodity},
                method="POST").text
    if "Successful Import Of Market Data" not in text:
        log('Import Of Market Data unsuccessful -> '+str(text))
        return False # Fail the cronicle step
    else:
        return True

def interpolate():
    coco = conf().cocos[0]
    text = http("balsarest/marketdata/interpolateForwardCurves", headers={"company": coco.company,
                                                                          "commodity": coco.commodity},
                method="POST").text
    if "Successful Interpolation of forward curves" not in text:
       log('Interpolation of forward curves unsuccessful -> '+str(text))
       return False # Fail the cronicle step
    else:
        return True

def revalue_forests():
    for coco in conf().cocos:
        text = http("balsarest/trading/revalueForest",
                    headers={"company": coco.company, "commodity": coco.commodity, "saveInDB": "N",
                             "trackChangesInQueue": "N"},
                    method="POST").text
        if "Successful Revaluation" not in text and "No contracts are available" not in text:
            log("revalue_forests failed for " + to_json(coco))
            return False # Fail the cronicle step
    return True

if __name__ == '__main__':
    start_job()
    imd_result = import_market_data()
    inter_result = interpolate()
    rev_result = revalue_forests()
    result = imd_result and inter_result and rev_result
    end_job(result)
