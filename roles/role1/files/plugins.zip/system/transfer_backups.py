import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

def move_backups_to_data_server():
    shell_command = 'expect transfer_files.exp'+' '+conf().appServer+' '+conf().client+' '+conf().svPwd+' '+conf().dbServer
    shell_command = shell_command.strip()
    result = subprocess.run(shell_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, shell=True)
    if result.returncode == 0:
        print('Successfully ran the command')
    else:
        raise Exception("Backup Transfer to Data Server Failed!")
    return

start_job()
move_backups_to_data_server()
end_job(True)
