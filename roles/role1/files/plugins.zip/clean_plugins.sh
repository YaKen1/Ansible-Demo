# When deploying a new version of the Maintenance package to an existing installation we can run this script to clean the existing plugins thus ensuring only the current set is present.
rm -rf ./balsamo/
rm -rf ./database/
rm -rf ./generic/
rm -rf ./system/