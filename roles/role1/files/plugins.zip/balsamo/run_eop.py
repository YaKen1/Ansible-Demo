import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *
from time import sleep


def check_eop():
    """
    Code returned by the webservice :
    N : Not started
    R : Running
    F : Failure
    S : Success
    I : Interrupted
    K : Skipped
    """
    try:
        response = http("balsarest/eop/getEOPStatus", headers={"eopType": params().type}, method="POST")
        if response.status_code != 201:
            return False
        text = response.text
        if ("state: F " in text) or ("state: I " in text):
            raise Exception("EOD failure")
        return ("state: R " not in text) and ("state: N " not in text)
    except:
        raise Exception("EOD failure")


start_job()
if http("balsarest/eop/runEOP", headers={"eopType": params().type}, method="POST").status_code == 201:
    sleep(5)
    success = wait(check_eop)
    end_job(success)
else:
    end_job(False)
