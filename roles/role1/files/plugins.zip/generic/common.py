import sys
import json
import requests
import os
from types import SimpleNamespace
from datetime import datetime
import pyodbc
import subprocess
from time import sleep


############## Utility methods ################


def read_json(file):
    """
    Read json from a file. Example :
    o = read_json(file)
    for x in o.persons:
        log(x.firstName, x.children[0].age)
    """
    return json.load(file, object_hook=lambda d: SimpleNamespace(**d))


def merge_dicts(a, b):
    """
    Merge two dictionaries. The values of b override the values of a.
    """
    return {**a, **b}


def to_json(x):
    """
    Convert an object to json (string). Example :
    log(to_json({"firstName":"John", lastName:"Smith"}))
    """
    return json.dumps(x, default=lambda o: o.__dict__)


############## Job basics ################


def start_job():
    """
    To call at the beginning of each job.
    Read the parameters, configuration and name of the log file.
    """
    global params, conf, log_file
    input_json = read_json(sys.stdin)
    params = input_json.params
    try:
        with open(os.path.abspath("../../conf/" + params.platform + ".json"), 'r') as file:
            conf = read_json(file)
    except Exception as e:
        print(e)
        log(e)
        conf = None
    log_file = input_json.log_file
    file = sys.argv[0]
    log("TO RUN THIS JOB MANUALLY : echo '" + to_json({"params": params, "log_file": "logs/" + file + ".log"})
        + "' | python3 " + file)
    log("Job started")


def params():
    """
    Parameter of the job. Provided by cronicle. Example :
    log(params().platform)
    """
    return params


def conf():
    """
    Configuration of the platform. See example conf file for structure. Example :
    log(conf().dbUser)
    """
    return conf


def common_conf():
    """
    Global configuration (not related to any customer platform)
    """
    return SimpleNamespace(schedulerServer="192.168.121.1", dataServer="192.168.126.1")


def log(message):
    """
    Log a message.
    Use with extreme scarcity : all requests, queries and commands are already logged.
    """
    global log_file
    message = "[" + str(datetime.now()) + "] " + str(message)
    with open(log_file, 'a') as file:
        file.write(message + "\n")


def end_job(complete, description=None):
    """
    To call at the end of each job to report success (complete=True) or failure (complete=False).
    If not called, the job will be considered as failed by cronicle.
    Description is most often useless.
    """
    if description is None:
        description = "Success" if complete else "Failure"
    print(json.dumps({"complete": int(complete), "description": description}))
    log("Job ended")


def progress(r):
    """
    Report progress : r between 0.0 and 1.0.
    Only use for long jobs. Example :
    for i in range(1000):
        work_hard(i)
        progress(i/1000.0)
    """
    print(json.dumps({"progress": r}))


def table(title, header, rows):
    """
    Display a table for cronicle.
    Only one table can be created for each job. Example :
    table("Persons", ["First name", "Last name"], [["John","Smith"],["Jacques","Dupont"]])
    """
    rows = [[str(elem) for elem in row] for row in rows]
    result = {"table": {"title": title, "header": header, "rows": rows}}
    print(json.dumps(result))


############## Methods ##################

def cmd(command, server=None):
    """
    Run a shell command on the app server. Example :
    cmd("sudo systemctl start wildfly")
    server is where the command is executed :
        - None (default) : on wildfily app server
        - "" : on local machine (scheduler machine)
        - Other : the server name
    """
    if server is None:
        log(conf)
        log(command)
        cmd = "ssh -t ceScheduler@" + conf.appServer + " '" + command + "'"
    elif server == "":
        cmd = command
    else:
        cmd = "ssh -t ceScheduler@" + server + " '" + command + "'"
    log(cmd)
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, shell=True)
    log("--> " + str(result.stdout))
    if result.stderr is not None \
            and len(str(result.stderr)) > 0 \
            and "Pseudo-terminal" not in str(result.stderr):
        raise Exception("Command returned error : " + str(result.stderr))


def expect_cmd(expect_command, expect_server=None):
    """Run a shell command on the app server. Example :
    expect_cmd("sudo systemctl start wildfly")
    expect_server is where the command is executed :
        - None (default) : on wildfily app server
        - "" : on local machine (scheduler machine)
        - Other : the server name
    """
    server_user = conf.client_server_user
    if expect_server is None:
        log(conf)
        log(expect_command)
        expect_cmd = "ssh {}@".format(server_user) + conf.appServer
    elif expect_server == "":
        expect_cmd = expect_command
    else:
        expect_cmd = "ssh {}@".format(server_user) + conf.appServer

    expect_cmd = '"' + conf.appServerPassword + '"' + ' ' + expect_cmd
    log(expect_cmd)
    expect_result = subprocess.run('expect command_ssh.exp '+expect_cmd+' '+expect_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, shell=True)
    log("--> " + str(expect_result.stdout))
    if expect_result.stderr is not None \
            and len(str(expect_result.stderr)) > 0 \
            and "Pseudo-terminal" not in str(expect_result.stderr):
        raise Exception("Command returned error : " + str(expect_result.stderr))
    else:
        pass

    return


def http(url, headers={}, method="GET"):
    """
    Execute an HTTP request server on the app server. Example :
    log(http("/balsarest/trading/blabla").text))
    """
    h = {"user": conf.appUser, "pwd": conf.appPassword}
    try:
        h = merge_dicts(h, {"company": params.company, "commodity": params.commodity})
    except:
        pass

    h = merge_dicts(h, headers)
    url = conf.appUrl + url
    print_h = h.copy()
    print_h["pwd"] = "*****"
    log(method + " " + url + " " + str(print_h))
    if method == "POST":
        response = requests.post(url, headers=h)
    else:
        response = requests.get(url, headers=h)

    h["pwd"] = "*****"
    log("--> (Code " + str(response.status_code) + ") " + response.text)
    return response


def sql(sql, withHeader=False, dbName=None, loopOnSets=False):
    """
    Run an SQL query on the db server.
    withHeader=True returns the name of the columns.
    Example :
    for row in sql("SELECT * FROM SYS_SYSTEMPARAMETERS"):
        log(row.name + "=" + row.value)
    """
    cnxn_str = (
            "Driver={ODBC Driver 17 for SQL Server};SERVER=" + conf.dbServer + ";DATABASE=" +
            (conf.dbName if dbName is None else dbName) + ";UID=" + conf.dbUser + ";PWD=" + conf.dbPassword + ";")
    log(sql)
    cnxn = pyodbc.connect(cnxn_str, autocommit=True)
    try:
        cursor = cnxn.cursor()
        try:
            cursor.execute(sql)
            if loopOnSets:
                while cursor.nextset():
                    pass
            if cursor.description is None:
                return
            else:
                result = cursor.fetchall()
                if len(result) < 30:
                    json = to_json(to_json([[str(elem) for elem in row] for row in result]))
                    if len(json) < 1000:
                        log("--> " + json)
                if withHeader:
                    return result, [i[0] for i in cursor.description]
                else:
                    return result
        finally:
            cursor.close()
    finally:
        cnxn.close()


def waitWithTimeout(method, timeout, interval=25):
    """
    Run a method until success (the method returns True) with a timeout.
    Returns True if the method returns a success at some point
    Returns False if the method failed all the way to the timeout or raised an exception.
    Example :
    waitWithTimeout(try_to_do, timedelta(minutes=10))
    """
    limit = datetime.now() + timeout
    while datetime.now() < limit:
        try:
            ok = method()
            if ok:
                return True
        except Exception as err:
            log(err)
            return False
        else:
            sleep(interval)
    return False


def wait(method, interval=25):
    """
    Run a method until success (the method returns True) with no timeout.
    Returns True if the method returns a success at some point
    Returns False if the method failed or raised an exception.
    Example :
    wait(try_to_do)
    """
    while True:
        try:
            ok = method()
            if ok:
                return True
        except Exception as err:
            log(err)
            return False
        else:
            sleep(interval)


def sql_date(date):
    """
    Format date for SQL
    """
    return "NULL" if date is None else "'" + datetime.strftime(date, "%Y-%m-%d 00:00:00.000000") + "'"


def sql_string(text):
    """
    Format string for SQL
    """
    return "NULL" if text is None else "'" + text.replace("'", "''") + "'"
