import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

def sqlServerAgentDisable():
    sqlJoBname = conf().sql_job_name
    for job in sqlJoBname:
        log(str(datetime.now()) + " [INFO] Disabling Automated SQL Agent Job = %s "%(str(job)))
        result = sql("EXEC dbo.sp_update_job @job_name = N'"+job+"', @description = N'Transaction Backup Disabled During Maintenance Procedure.', @enabled = 0")
        if(result == True):
            log(str(datetime.now())+ " [INFO] Automated SQL Agent Jobs = %s is Disabled"%(str(job)))
        else:
            log(str(datetime.now()) + " [ERROR] Automated SQL Agent Jobs Not Disabled !")

def sqlServerAgentEnable():
    sqlJoBname = conf().sql_job_name
    for job in sqlJoBname:
        result = sql("EXEC dbo.sp_update_job @job_name = N'"+job+"', @description = N'Transaction Backup Enabled After Maintenance Procedure.', @enabled = 1")
        if(result == True):
            log(str(datetime.now())+ " [INFO] Automated SQL Agent Job = %s is Enabled"%(str(job)))
        else:
            log(str(datetime.now()) + " [ERROR] Automated SQL Agent Jobs Not Enabled !")

if __name__ == '__main__':
    start_job()
    if params().mode == "enableAgent":
        result = sqlServerAgentEnable()
    else:
        result = sqlServerAgentDisable()
    end_job(result)