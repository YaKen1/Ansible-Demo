import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *

def maintenance():
    if params().mode == 'startMaintenance' or params().mode == 'stopMaintenance':
        request_string = 'balsarest/system/{}'.format(str(params().mode))
        response = http(request_string, headers={"Company": params().company,
                    "Commodity": params().commodity}, method="POST")
        if response.status_code == 202:
            return
        raise Exception(response.text)
    else:
        raise Exception("Invalid mode supplied: " + params().mode + ", Maintenance plugin failed!")


start_job()
maintenance()
end_job(True)
