import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *


def get_indexes():
    query = "SELECT T.name TABLE_NAME, I.name INDEX_NAME, I.type_desc INDEX_TYPE, " \
            "s.page_count PAGE_COUNT, s.avg_fragmentation_in_percent FRAG_PERCENT " \
            "FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) S " \
            "INNER JOIN sys.indexes I ON I.index_id = S.index_id  and S.object_id = I.object_id " \
            "INNER JOIN sys.tables T ON T.object_id = I.object_id " \
            "WHERE I.name IS NOT NULL"
    if params().type != "ALL":
        query += " AND I.type_desc = " + sql_string(params().type)
    query += " ORDER BY I.type_desc,S.page_count"
    return sql(query)


def to_dict(before):
    b = {}
    for row in before:
        b[row.TABLE_NAME + "." + row.INDEX_NAME] = [row.INDEX_TYPE, row.PAGE_COUNT, row.FRAG_PERCENT]
    return b


def report(before, after):
    b = to_dict(before)
    a = to_dict(after)
    result = []
    for key, value in b.items():
        if value[1] > 1000:
            result.append([key, value[0], value[1], value[2], a[key][2]])
    result.sort(key=lambda row: row[2], reverse=True)
    table("Summary", header=["INDEX", "INDEX_TYPE", "PAGE_COUNT", "FRAG_BEFORE", "FRAG_AFTER"], rows=result)


start_job()
rows = get_indexes()
if params().action != 'STATS ONLY':
    total = sum([row.PAGE_COUNT + 1000 for row in rows])
    done = 0
    for row in rows:
        sql("ALTER INDEX " + row.INDEX_NAME + " ON " + row.TABLE_NAME + " " + params().action)
        done += row.PAGE_COUNT + 1000
        progress(done / float(total))
report(rows, get_indexes())
end_job(True)
