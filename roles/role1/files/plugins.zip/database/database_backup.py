import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *
from datetime import datetime

def backup_the_database(db_name, db_excryption, db_backup_filepath):

    if db_excryption.upper() != 'NO':
        # Does the backup
        sql("BACKUP DATABASE [" + db_name + "] READ_WRITE_FILEGROUPS, FILEGROUP = N'PRIMARY' TO DISK = N"
            + sql_string(backup_file) +
            " WITH FORMAT, COMPRESSION, NAME = 'BALSAMO-full', SKIP, NOREWIND, NOUNLOAD, STATS = 10,"
            " ENCRYPTION (ALGORITHM = AES_256,SERVER CERTIFICATE = " + db_excryption + ")"
            , loopOnSets=True)
    else:
        sql("BACKUP DATABASE [" + db_name + "] READ_WRITE_FILEGROUPS, FILEGROUP = N'PRIMARY' TO DISK = N'"
            + db_backup_filepath +
            "' WITH FORMAT, COMPRESSION, NAME = 'BALSAMO-full', SKIP, NOREWIND, NOUNLOAD, STATS = 10")

    return

if __name__ == '__main__':
    start_job()

    backup_path = conf().db_backup_filepath
    db_excryption = conf().dbEncryptionCertificate
    db_name = conf().dbName

    backup_file = backup_path + params().platform + "_" + datetime.now().strftime("%Y-%m-%d") + ".bak"
    backup_the_database(db_name, db_excryption, backup_file)
    
    end_job(True)