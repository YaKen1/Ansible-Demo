import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *
from datetime import datetime

start_job()

# For windows : pathToDisk = "C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\Backup\BALSAMO_" + str(env) + "_" + str(todayFormated) + ".bak"
backup_file = "DBBackups/BALSAMO_" + params().platform + "_" + datetime.now().strftime("%Y-%m-%d") + ".bak"

# Take db offline and then online again to allow setting IndexesFG to READ_ONLY
sql("ALTER DATABASE [" + conf().dbName + "] SET OFFLINE WITH ROLLBACK IMMEDIATE")
sql("ALTER DATABASE [" + conf().dbName + "] SET ONLINE", dbName="master")

# Set IndexesFG to READ_ONLY (because the backup could not be restored otherwise)
# sql("ALTER DATABASE [" + conf().dbName + "] MODIFY FILEGROUP [IndexesFG] READ_ONLY")

# Does the backup
sql("BACKUP DATABASE [" + conf().dbName + "] READ_WRITE_FILEGROUPS, FILEGROUP = N'PRIMARY' TO DISK = N"
    + sql_string(backup_file) +
    " WITH FORMAT, COMPRESSION, NAME = 'BALSAMO-full', SKIP, NOREWIND, NOUNLOAD, STATS = 10,"
    " ENCRYPTION (ALGORITHM = AES_256,SERVER CERTIFICATE = " + conf().dbEncryptionCertificate + ")"
    , loopOnSets=True)

# Copy file to data server
# data_server_path = conf().dataserverUser + "@" + common_conf().dataServer + ":/var/CE/Client/" + params().platform
# cmd("scp -o \"ProxyJump root@" + common_conf().schedulerServer + "\" "
#     + conf().dbServer + ":/var/opt/mssql/data/" + backup_file
#     + " " + data_server_path, server="")

# Set IndexesFG to READ_WRITE again
# sql("ALTER DATABASE [" + conf().dbName + "] MODIFY FILEGROUP [IndexesFG]' READ_WRITE")

end_job(True)
