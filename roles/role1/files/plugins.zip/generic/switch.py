from common import *
from datetime import datetime

start_job()
day = "day" + str(datetime.now().weekday())
log("We are " + day)
success = params().__dict__[day] == 1
end_job(success)
