import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

def stop_wildfly(user, host, password):
    expect_script_path = 'expect_wildfly_stop.exp'

    try:
        # Execute the expect script with user, host, and password
        result = subprocess.run(['expect', expect_script_path, user, host, password], capture_output=True, text=True)
    
        # Print the expect script output
        log(result.stdout)
        # Determine success based on the output
        if "SUCCESS" in result.stdout:
            return True
        else:
            return False
    except subprocess.CalledProcessError as e:
        log("Error:", e.output)
        return False

if __name__ == '__main__':
    # Example usage
    start_job()
    user = conf().client_server_user
    host = conf().appServer
    password = conf().appServerPassword
    if stop_wildfly(user, host, password):
        log("WildFly is successfully stopped.")
        end_job(True)
    else:
        log("Failed to stop WildFly.")
        end_job(False)
