import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

start_job()
expect_cmd("sudo /root/new_stop_wildfly.sh")
end_job(True)
