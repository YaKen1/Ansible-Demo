import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

def clear_previous_backups():
    shell_command = 'expect clear_previous_backups.exp'+' '+conf().dbServer+' '+conf().svPwd
    shell_command = shell_command.strip()
    result = subprocess.run(shell_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, shell=True)
    if result.returncode == 0:
        print('Successfully cleared previous backups')
    else:
        raise Exception("Failed to clear previous backups!")
    return

start_job()
clear_previous_backups()
end_job(True)
