import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *

def create_next_period():
    response = http("balsarest/financialcontrol/createNextClosingPeriod", headers={"Company": params().company,
                "Commodity": params().commodity}, method="POST")
    log(response.text)
    if  response.status_code == 400 or response.status_code == 403:
        if "already exist" in response.text:
            return
        raise Exception("Create Next Period Failed")
    return

start_job()
create_next_period()
end_job(True)
