import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)
    
from common import *


def send_report():
    text = http("balsarest/reporting/sendReport", headers={"classname": params().classname},
                method="POST").text
    if "Successful Send Report" not in text:
        raise Exception("sendReport Failed")

if __name__ == '__main__':
    start_job()
    send_report()
    end_job(True)
