
import sys
import os
import re
from time import sleep
import requests

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *

def interpolate_forward_curves():
    try:
        response = http("balsarest/marketdata/interpolateForwardCurves", method="POST")
        if response.status_code == 201:
            return True
        log(response.text)
        return False
    except requests.RequestException as e:
        log(f'An error occurred: {e}')
        return False


if __name__ == '__main__':
    start_job()
    success = interpolate_forward_curves()
    end_job(success)