import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

start_job()
rows, header = sql(params().sql, withHeader=True)
table(title="Result", header=header, rows=rows)
end_job(True)
