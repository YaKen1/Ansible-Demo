import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

def manage_wildfly(user, host, password):
    expect_script_path = 'expect_wildfly_start.exp'
    # Execute the expect script with user, host, and password
    result = subprocess.run(['expect', expect_script_path, user, host, password], capture_output=True, text=True)
   
    # Print the expect script output
    log(result.stdout)
    # Determine success based on the output
    if "SUCCESS: WildFly is running." in result.stdout:
        return True
    elif "ERROR: WildFly failed to start after retry." in result.stdout:
        return False


if __name__ == '__main__':
    # Example usage
    start_job()
    user = conf().client_server_user
    host = conf().appServer
    password = conf().appServerPassword
    if manage_wildfly(user, host, password):
        log("WildFly is successfully running.")
        end_job(True)
    else:
        log("Failed to start WildFly.")
        end_job(False)
