import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *

def daily_rebuild():
    log(str(datetime.now()) + " [INFO] Rebuilding TRA_CTBRULES ")
    result = sql("ALTER INDEX ALL ON [TRA_CTBRULES] REBUILD")
    if result is None:
        pass
    else:
        return False

    log(str(datetime.now()) + " [INFO] Rebuilding TRA_CTBRPARAMVALUES ")
    result = sql("ALTER INDEX ALL ON [TRA_CTBRPARAMVALUES] REBUILD")
    if result is None:
        return True
    else:
        return False
    
if __name__ == '__main__':
    start_job()
    result = daily_rebuild()
    end_job(result)