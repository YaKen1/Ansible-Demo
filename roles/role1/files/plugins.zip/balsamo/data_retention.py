from workalendar.europe import Geneva, Switzerland, UnitedKingdom, Edinburgh, UnitedKingdomNorthernIreland
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta, FR
import calendar
import requests
import time

import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *

# Finds the closing periods to be kept between the oldest date calculated and the date x 'periods_prior' to the day this is being run
def calculate_dates_between(cal,
    oldest_date, today, adjust_holidays_direction, periods_prior=0, period_type='Month', first_day=False, last_day=False, 
    first_working_day=False, last_working_day=False, last_friday=False,
    adjust_holidays=False, year_close_prior=0, apply_holiday_adjustment_to_month_end=False):
    
    result_dates = []

    cutoff_date = find_cutoff_date(today, periods_prior, period_type) # Find the cutoff date for the API call 

    current_date = oldest_date
    while current_date <= cutoff_date:
        date = None

        if first_day:
            date = datetime(current_date.year, current_date.month, 1)
            datetime_obj = datetime(date.year, date.month, date.day)
            result_dates.append(datetime_obj)
        if last_day:
            _, last_day_of_month = calendar.monthrange(current_date.year, current_date.month)
            date = datetime(current_date.year, current_date.month, last_day_of_month)
            datetime_obj = datetime(date.year, date.month, date.day)
            result_dates.append(datetime_obj)
        if first_working_day:
            chk_date = datetime(current_date.year, current_date.month, 1)
            date = cal.find_following_working_day(chk_date)
            datetime_obj = datetime(date.year, date.month, date.day)
            result_dates.append(datetime_obj)
        if last_working_day:
            date = cal.get_last_weekday_in_month(current_date.year, current_date.month, 0)
            datetime_obj = datetime(date.year, date.month, date.day)
            result_dates.append(datetime_obj)
        if last_friday:
            datetime_obj = datetime(current_date.year, current_date.month, current_date.day)+relativedelta(day=31, weekday=FR(-1), months=1)
            result_dates.append(datetime_obj)


        current_date += timedelta(days=1)
    year_end_cleared = retain_year_ends(cal, cutoff_date, result_dates, year_close_prior, adjust_holidays, adjust_holidays_direction, apply_holiday_adjustment_to_month_end) # Retain only the year ends from x year_close_prior

    return sorted(set(year_end_cleared)), cutoff_date

def retain_year_ends(cal, cutoff_date, result_dates, year_close_prior, adjust_holidays, adjust_holidays_direction, apply_holiday_adjustment_to_month_end):
    year_end_cleared = []
    for date in result_dates:
        if date.year == cutoff_date.year or (date.year == cutoff_date.year-(1+year_close_prior) and date.month == 12):
            year_end_cleared.append(date)

    if adjust_holidays:
        year_end_cleared = adjust_for_holidays(cal, year_end_cleared, adjust_holidays_direction, apply_holiday_adjustment_to_month_end) # Adjust closing periods based on whether clients want the previous working day or next working day if it is a holiday
    return year_end_cleared

def adjust_for_holidays(cal, year_end_cleared, adjust_holidays_direction='previous', apply_holiday_adjustment_to_month_end=False):
    new_result = []
    for date in year_end_cleared:
        if (apply_holiday_adjustment_to_month_end):
            if not cal.is_working_day(date):
                datetime_obj = datetime(date.year, date.month, date.day)
                new_result.append(datetime_obj)
                if adjust_holidays_direction == 'previous':
                    while not cal.is_working_day(date):
                        date -= timedelta(days=1)
                    datetime_obj = datetime(date.year, date.month, date.day)
                    new_result.append(datetime_obj)
                elif adjust_holidays_direction == 'next':
                    while not cal.is_working_day(date):
                        date += timedelta(days=1)
                    datetime_obj = datetime(date.year, date.month, date.day)
                    new_result.append(datetime_obj)  
            else:
                datetime_obj = datetime(date.year, date.month, date.day)
                new_result.append(datetime_obj)
        else:
            if not cal.is_working_day(date) and date.month>=12:
                datetime_obj = datetime(date.year, date.month, date.day)
                new_result.append(datetime_obj)
                if adjust_holidays_direction == 'previous':
                    while not cal.is_working_day(date):
                        date -= timedelta(days=1)
                    datetime_obj = datetime(date.year, date.month, date.day)
                    new_result.append(datetime_obj)
                elif adjust_holidays_direction == 'next' and date.month>=12:
                    while not cal.is_working_day(date):
                        date += timedelta(days=1)
                    datetime_obj = datetime(date.year, date.month, date.day)
                    new_result.append(datetime_obj)  
            else:
                datetime_obj = datetime(date.year, date.month, date.day)
                new_result.append(datetime_obj)  

    return new_result

def find_cutoff_date(today, periods_prior, period_type):
    today = today - relativedelta(days=1)
    if period_type == 'Month':
        cutoff_date = today - relativedelta(months=periods_prior)
    elif period_type == 'Day':
        cutoff_date = today - relativedelta(days=periods_prior)    
    else:
        cutoff_date = today - relativedelta(months=periods_prior)

    return cutoff_date

# API driver method 
def initiate_data_retention(post_url, get_url, data, headers):
    search_text = 'End deleting trading data for periods younger than:'  # This should match the success response from the API
    failure_text = 'Exception'      # This should match the failure response from the API I could not find it within the code, should have no effect if error status returned
    completed = False

    try:
        # Initiate data retention by sending a POST request
        response = requests.post(post_url, json=data, headers=headers)
        response.raise_for_status()  # Raise an exception for HTTP errors

        if response.status_code > 199 and response.status_code < 300:
            log("Data Retention was successfully initiated.")
        else:
            log(f"Data Retention initiation failed with status code {response.status_code}.")
            return False # Exit the function in case of failure

        # Poll the progress until completed
        while not completed:
            try:
                get_response = requests.get(get_url, headers=headers)
                get_response.raise_for_status()

                if search_text in get_response.text:
                    completed = True
                    log("Data Retention completed successfully.")
                elif failure_text in get_response.text:
                    raise Exception('The deletion failed with the following response: {}'.format(get_response.text)) # Cleanup failed with handled error kill the program
                else:
                    log("Data Retention in progress. Waiting for 2 minutes...")
                    time.sleep(120)  # Wait 2 minutes and check again
            except requests.exceptions.RequestException as e:
                log('Error in GET request: {}'.format(e))   
                return False     
    except requests.exceptions.RequestException as e:
        log('Error in POST request: {}'.format(e))
        return False 
    
    return True

# Takes in the set of parameters to generate the headers and data dictionaries to be supplied to the API call
def generate_api_data(closing_periods, cutoff_date, username, password, company, commodity, oldest_date, index_rebuild="N", batch_size=1, dbShrink="N"):
    headers = {
        "Content-Type": "application/json",
        "User": "{}".format(username),
        "pwd": "{}".format(password),
        "Company": "{}".format(company),
        "Commodity": "{}".format(commodity),
    }

    data = {
        "method": "delete",
        "cutOffClosingPeriod": cutoff_date.strftime("%d/%m/%Y"),
        "logShrinkFreq": "{}".format(batch_size),
        "dbShrink": dbShrink, # This is a string supplied in the params
        "oldestClosingPeriod": oldest_date.strftime("%d/%m/%Y"),
        "withIndexesRebuild": index_rebuild, # This is a string supplied in the params
        "batchSize": "{}".format(batch_size),
        "ClosingPeriods": closing_periods
    }

    return headers, data

def display_data(cutoff_date, oldest_date, headers, data, post_url, get_url, test_no=0):
    log('======== Test {} ========'.format(test_no))
    log('This is the cutoff date')
    log(cutoff_date)
    log('This is the oldest closing period')
    log(oldest_date)
    log('=========== + ===========')
    log(headers)
    log(data)
    log('=========================')
    log('=========== urls ==========')
    log('post')
    log(post_url)
    log('get')
    log(get_url)
    return

def weekly_data_retention(username, pwd, company, commodity, set_oldest_retention_date, holiday_calendar, periods_prior, period_type, adjust_holidays_direction, first_day=False, last_day=False, first_working_day=False, last_working_day=False, last_friday=False,
        adjust_holidays=False, year_close_prior=0, apply_holiday_adjustment_to_month_end=False, app_url='http://127.0.0.1:8083/balsacore/'):
    # Example usage:
    cal = holiday_calendar
    periods_prior = int(periods_prior)

    today = datetime.now()
    today_year = today
    if period_type == 'Month':
        today_year -= timedelta(days=periods_prior*31)
    elif period_type == 'Day':
        today_year -= timedelta(days=periods_prior)
    else:
        today_year -= timedelta(days=periods_prior*31)
    oldest_date = datetime(today_year.year-year_close_prior, 1, 1) 
    # Due to necessity of initial cleans it is safe to always use the batch size 10
    batch_size = 10

    result, cutoff_date = calculate_dates_between(
        cal, oldest_date, today, adjust_holidays_direction, periods_prior, period_type, first_day, last_day, first_working_day, last_working_day, last_friday,
        adjust_holidays, year_close_prior, apply_holiday_adjustment_to_month_end
    )

    closing_periods = [date.strftime("%d/%m/%Y") for date in result] # Convert the datetime objects to strings

    try:
        set_oldest_retention_date_date_object = datetime.strptime(set_oldest_retention_date, "%d/%m/%Y")
    except Exception:
        log("Oldest retention date not properly set in maintenance_configuration.json please use the format dd/mm/YYYY")
        return False

    if set_oldest_retention_date_date_object > oldest_date:
        oldest_date = set_oldest_retention_date_date_object
    else:
        pass

    headers, data = generate_api_data(closing_periods, cutoff_date, username, pwd, company, commodity, oldest_date, index_rebuild="Y", batch_size=batch_size, dbShrink="Y")

    post_url = app_url+'balsarest/system/retainTradingDataForClosingPeriods' # POST URL to initiate data retention 
    get_url = app_url+'balsarest/system/getRetainTradingDataLogs' # GET URL for progress monitoring and logging

    display_data(cutoff_date, oldest_date, headers, data, post_url, get_url)

    # Below is the main driver for the data retention api requests
    #if (initiate_data_retention(post_url, get_url, data, headers)):
    #    log('Step for batch size: {} has completed successfully'.format(batch_size))
    #    return True
    #else:
    #    log('There was an error function returned False for batch size: {}'.format(batch_size))
    #    return False

if __name__ == '__main__':
    start_job()
    success = weekly_data_retention(conf().appUser, conf().appPassword, conf().company, 
                          conf().commodity, conf().set_oldest_retention_date, Geneva(), 
                          conf().retention_periods, conf().retention_period_type, conf().adjust_holidays_direction, 
                          first_day=conf().keep_month_start, last_day=conf().keep_month_end, 
                          first_working_day=conf().keep_month_first_work_day,
                          last_working_day=conf().keep_month_last_work_day,
                          last_friday=conf().keep_month_last_friday,
                          adjust_holidays=conf().apply_holiday_adjustment, 
                          year_close_prior=conf().year_close_prior, 
                          apply_holiday_adjustment_to_month_end=conf().apply_holiday_adjustment_to_month_end,
                          app_url=conf().appUrl)
    end_job(success)