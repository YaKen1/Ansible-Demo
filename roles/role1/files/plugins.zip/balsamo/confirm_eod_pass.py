import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)

from common import *
from datetime import timedelta
from time import sleep


def check_eop(coco):
    """
    Code returned by the webservice :
    N : not started
    R : running
    F : failure
    S : success
    I : interrupted
    K : skipped
    """
    try:
        response = http("balsarest/eop/getEOPStatus", headers={"eopType": "EOD", "company": coco.company, "commodity": coco.commodity}, method="POST") # hardcoded to eod
        if response.status_code != 201:
            return False
        text = response.text
        if ("EOD state: S " in text):
            return True
        elif ("EOD state: F " in text) or ("EOD state: I " in text):
            raise Exception("EOD failure")
        else:
            return ("EOD state: R " not in text) and ("EOD state: N " not in text)
    except:
        return False


start_job()
success = False
for coco in conf().cocos:
    success = check_eop(coco)
    if not success:
        break
    pass
end_job(success)
