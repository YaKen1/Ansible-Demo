import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *


def load_balsamo_screen():
    try:
        log("Starting")
        url = conf().appUrl
        log(subprocess.check_output(["curl", url]))
        log("about to return")
        return True
    except Exception as e:
        log(e)
        return False


if __name__ == '__main__':
    start_job()
    success = load_balsamo_screen()
    end_job(success)