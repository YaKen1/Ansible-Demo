import sys
import os

generic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'generic'))

if generic_dir not in sys.path:
    sys.path.append(generic_dir)


from common import *


def get_param_value(name):
    return sql("SELECT VALUE FROM SYS_SYSTEMPARAMETERS WHERE NAME=" + sql_string(name))[0].VALUE


def set_param_value(name, value):
    sql("UPDATE SYS_SYSTEMPARAMETERS SET VALUE=" + sql_string(value) + " WHERE NAME=" + sql_string(name))


start_job()
lines = []
for name in params().__dict__:
    if name != "platform":
        old = get_param_value(name)
        value = params().__dict__[name]
        if value != 'unchanged':
            set_param_value(name, value)
        lines.append([name, old, value])

table("SYS_SYSTEMPARAMETERS", ["NAME", "OLD VALUE", "NEW VALUE"], lines)
end_job(True)
